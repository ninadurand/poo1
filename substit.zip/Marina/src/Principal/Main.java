package Principal;
public class Main {
    public static void main(String[] args) {
        Shopping shopping = new Shopping();
        shopping.iniciarSistema();
    }
}
